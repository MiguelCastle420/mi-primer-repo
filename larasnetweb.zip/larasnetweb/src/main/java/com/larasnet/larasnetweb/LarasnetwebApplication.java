package com.larasnet.larasnetweb;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LarasnetwebApplication {
  public static void main(String[] args) {
    SpringApplication.run(LarasnetwebApplication.class, args);
  }
}
